package com.istateca.app.istateca.daos;

import com.istateca.app.istateca.models.BibliotecarioCargo;
import org.springframework.stereotype.Repository;

@Repository
public interface BibliotecarioCargoRepository extends BaseRepository<BibliotecarioCargo,Integer>{
}
