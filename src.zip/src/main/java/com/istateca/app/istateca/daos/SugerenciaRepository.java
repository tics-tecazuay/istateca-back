package com.istateca.app.istateca.daos;

import com.istateca.app.istateca.models.Sugerencia;
import org.springframework.stereotype.Repository;

@Repository
public interface SugerenciaRepository extends BaseRepository<Sugerencia,Integer>{
}
