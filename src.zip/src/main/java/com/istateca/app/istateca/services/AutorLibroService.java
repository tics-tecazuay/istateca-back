package com.istateca.app.istateca.services;

import com.istateca.app.istateca.models.AutorLibro;

public interface AutorLibroService extends BaseService<AutorLibro, Integer> {
}
