package com.istateca.app.istateca.services;

import com.istateca.app.istateca.models.BibliotecarioCargo;

public interface BibliotecarioCargoService extends BaseService<BibliotecarioCargo, Integer> {
}
