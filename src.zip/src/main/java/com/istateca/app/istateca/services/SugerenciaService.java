package com.istateca.app.istateca.services;

import com.istateca.app.istateca.models.Sugerencia;

public interface SugerenciaService extends BaseService<Sugerencia, Integer>{
}
